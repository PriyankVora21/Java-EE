package Vo;

public class reg_Vo {
private String fn,ln;
private int id;

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getFn() {
	return fn;
}

public void setFn(String fn) {
	this.fn = fn;
}

public String getLn() {
	return ln;
}

public void setLn(String ln) {
	this.ln = ln;
}	

}
