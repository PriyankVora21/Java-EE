package Dao;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import Vo.reg_Vo;


public class reg_dao {
	public void insert(reg_Vo v)
	{
		try{
		SessionFactory sessionfactory = new Configuration().configure().buildSessionFactory();
	 Session session = sessionfactory.openSession();
	Transaction transaction=session.beginTransaction();
	 session.save(v);
	 transaction.commit();
	 session.close();
		}catch(Exception e){}
	}

}
