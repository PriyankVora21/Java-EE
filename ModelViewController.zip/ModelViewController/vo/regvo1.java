package vo;

public class regvo1 {
	
private int id;
private String fn;
private String ln;
private String un;
private 	String pass;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getFn() {
	return fn;
}
public void setFn(String fn) {
	this.fn = fn;
}
public String getLn() {
	return ln;
}
public void setLn(String ln) {
	this.ln = ln;
}
public String getUn() {
	return un;
}
public void setUn(String un) {
	this.un = un;
}
public String getPass() {
	return pass;
}
public void setPass(String pass) {
	this.pass = pass;
}

}
