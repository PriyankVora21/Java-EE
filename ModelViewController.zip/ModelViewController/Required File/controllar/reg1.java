package controllar;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import vo.regvo1;
import dao.regdao1;

/**
 * Servlet implementation class reg1
 */
@WebServlet("/reg1")
public class reg1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public reg1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String key= request.getParameter("key");
		if(key.equals("s"))
		{
			search(request,response);
		}
		else if(key.equals("d"))
		{
			delete(request,response);
		}
		else if(key.equals("e"))
		{
			search_for_edit(request,response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		String key= request.getParameter("key");
		
		if(key.equals("i"))
		{
			insert(request,response);
		}
		else if(key.equals("update"))
		{
			update(request,response);
		}
	}
	
	protected void search_for_edit(HttpServletRequest request,HttpServletResponse response)
	{
	 String id=request.getParameter("id");
	 System.out.println(id);
	 regdao1 d=new regdao1();
	 List<regvo1> l=d.edit(id);
	 System.out.println(l.size());
	 HttpSession s=request.getSession();
     s.setAttribute("l",l);
     try{
	       response.sendRedirect("lec1/update1.jsp");
	       }catch(Exception e){}
	 
	}
	protected void update(HttpServletRequest request,HttpServletResponse response)
	{
		String fn=request.getParameter("fn");
		String ln=request.getParameter("ln");
		String id=request.getParameter("id");
		 regvo1 v=new regvo1();
		    v.setFn(fn);
		    v.setLn(ln);
		  regdao1 d=new regdao1();
		  d.update(id,v);
		  search(request,response);
	}
	protected void delete(HttpServletRequest request,HttpServletResponse response)
	{
		 regdao1 d=new regdao1();
		  String id=request.getParameter("id");
		 d.delete(id);
		 search(request,response);
	}
	protected void search(HttpServletRequest request,HttpServletResponse response)
	{
		regdao1 d=new regdao1();
	     List<regvo1> l=d.search();
	       
	       HttpSession s=request.getSession();
	       s.setAttribute("l",l);
	       try{
	       response.sendRedirect("lec1/table1.jsp");
	       }catch(Exception e){}
	}
    protected	void insert(HttpServletRequest request,HttpServletResponse response)
   {
    	String fn=request.getParameter("fn");
	    String ln=request.getParameter("ln");
	    String un=request.getParameter("un");
	    String pass=request.getParameter("pass");
	    
	    regvo1 v=new regvo1();
	    v.setFn(fn);
	    v.setLn(ln);
	    v.setPass(pass);
	    v.setUn(un);
	    
	    regdao1 d=new regdao1();
	    d.insert(v);
   }

}
