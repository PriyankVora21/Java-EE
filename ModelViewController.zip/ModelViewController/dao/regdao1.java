package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import java.util.*;

import vo.regvo1;

public class regdao1 {
	
	public void insert(regvo1 r)
	{
		 try{
			 Class.forName("com.mysql.jdbc.Driver");
			 Connection c=DriverManager.getConnection("jdbc:mysql://localhost/testdb","root","root");
			 Statement s=c.createStatement();
			 s.executeUpdate("insert into register_detail(Firstname,Lastname,Username,Password) values('"+r.getFn()+"','"+r.getLn()+"','"+r.getUn()+"','"+r.getPass()+"')");
			 c.close();
			 }catch(Exception e){}
	}
	public List<regvo1> edit(String id)
	{
		List<regvo1> l=new ArrayList<regvo1>();
		 try
		  {
			 Class.forName("com.mysql.jdbc.Driver");
			 Connection c=DriverManager.getConnection("jdbc:mysql://localhost/testdb","root","root");
		     Statement s=c.createStatement();
		     ResultSet r= s.executeQuery("select id,Firstname,Lastname from register_detail where id='"+id+"'");
		     
		     while(r.next())
		     {
		    	 String fn=r.getString("Firstname");
		    	 String ln=r.getString("Lastname");
		    	 regvo1 v=new regvo1();
		    	 v.setId(Integer.parseInt(id));
		    	 v.setFn(fn);
				 v.setLn(ln);
				 l.add(v);
				 c.close();
		     }
		  }catch(Exception e){}
		 
		 return l;
	}
	public void update(String id,regvo1 v)
	{
		 try
		  {
			 Class.forName("com.mysql.jdbc.Driver");
			 Connection c=DriverManager.getConnection("jdbc:mysql://localhost/testdb","root","root");
		     Statement s=c.createStatement();
		     s.executeUpdate("Update register_detail set Firstname='"+v.getFn()+"',Lastname='"+v.getLn()+"' where id='"+id+"' ");
		  }catch(Exception e){}
	}
	public List<regvo1> search()
	{
		 List<regvo1> l=new ArrayList<regvo1>();
	  try
	  {
		 Class.forName("com.mysql.jdbc.Driver");
		 Connection c=DriverManager.getConnection("jdbc:mysql://localhost/testdb","root","root");
	     Statement s=c.createStatement();
	     
        ResultSet r=s.executeQuery("select * from register_detail");
		 
		 while(r.next())
		 {  
			 int id=r.getInt("id");
			 String fn=r.getString("Firstname");
			 String ln=r.getString("Lastname");
			 String un=r.getString("Username");
			 String pass=r.getString("Password");
			 regvo1 v=new regvo1();
			 
			 v.setId(id);
			 v.setFn(fn);
			 v.setLn(ln);
			 v.setPass(pass);
			 v.setUn(un);
			 l.add(v);
		 }
		 c.close();
		
	  }catch(Exception e){}
	  return l;
	}
	public void delete(String id)
	 {
		 try
		 {
			 Class.forName("com.mysql.jdbc.Driver");
			 Connection c=DriverManager.getConnection("jdbc:mysql://localhost/testdb","root","root");
			 Statement s=c.createStatement();
			 s.executeUpdate("delete from register_detail where id='"+id+"' ");
		 }catch(Exception e){}
	 }

}
